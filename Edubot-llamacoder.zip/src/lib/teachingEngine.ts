import { getKeywordsBySubject } from "../utils/keywords";

export type Level = "beginner" | "intermediate" | "advanced";

interface Response {
  explanation: string;
  shouldQuiz: boolean;
  socraticQuestion?: string;
}

export function detectLevel(input: string, subject: string): Level {
  const keywords = getKeywordsBySubject(subject);
  const words = input.toLowerCase().split(/\s+/);
  
  // Check for advanced indicators
  const advancedIndicators = ["complex", "algorithm", "theorem", "prove", "derive", "optimize", "implement"];
  const intermediateIndicators = ["explain", "how", "why", "compare", "difference", "relationship"];
  
  const hasAdvanced = advancedIndicators.some(indicator => 
    input.toLowerCase().includes(indicator)
  );
  
  const hasIntermediate = intermediateIndicators.some(indicator => 
    input.toLowerCase().includes(indicator)
  );
  
  const hasKeywords = keywords.advanced.some(keyword => 
    words.includes(keyword.toLowerCase())
  );
  
  if (hasAdvanced || hasKeywords) return "advanced";
  if (hasIntermediate) return "intermediate";
  return "beginner";
}

export function generateResponse(input: string, subject: string, level: Level): Response {
  const responses = getResponseBySubject(subject, level, input);
  return responses[Math.floor(Math.random() * responses.length)];
}

function getResponseBySubject(subject: string, level: Level, input: string): Response[] {
  const baseResponses = {
    general: {
      beginner: [
        {
          explanation: "That's a great starting question! Let's think about this step by step. First, what do you already know about this topic? Understanding what you know helps me explain it better.",
          shouldQuiz: true,
        },
        {
          explanation: "I'd like to help you understand this concept. Before I explain, can you tell me what made you curious about this? Sometimes knowing your motivation helps tailor the explanation.",
          shouldQuiz: true,
        },
      ],
      intermediate: [
        {
          explanation: "This is an interesting question that builds on fundamental concepts. Let me break this down: First, consider the basic principles involved. Then, we'll explore how they connect to create the bigger picture you're asking about.",
          shouldQuiz: true,
        },
        {
          explanation: "To understand this properly, we need to consider multiple factors. Let's start with the core mechanism and then examine how different variables influence the outcome.",
          shouldQuiz: true,
        },
      ],
      advanced: [
        {
          explanation: "This requires analyzing the underlying principles and their interconnections. Let's examine the theoretical framework first, then consider practical applications and edge cases that might challenge our understanding.",
          shouldQuiz: true,
        },
        {
          explanation: "At this level, we need to consider both the formal definitions and their implications. The key insight here is understanding not just what happens, but why it happens that way under different conditions.",
          shouldQuiz: true,
        },
      ],
    },
    math: {
      beginner: [
        {
          explanation: "Math is like building with blocks! Let's start with the simplest piece and build up. Think of this concept as a tool that helps us solve problems. What kind of problems do you think this might help with?",
          shouldQuiz: true,
        },
      ],
      intermediate: [
        {
          explanation: "This mathematical concept connects several ideas you might already know. Let's establish the formal definition first, then explore how it relates to other concepts you've encountered.",
          shouldQuiz: true,
        },
      ],
      advanced: [
        {
          explanation: "We need to consider the rigorous proof structure and underlying axioms. This concept emerges from more fundamental principles, and understanding those will give you deeper insight into why this works the way it does.",
          shouldQuiz: true,
        },
      ],
    },
    science: {
      beginner: [
        {
          explanation: "Science helps us understand how the world works! Let's imagine this concept in everyday life. Have you ever noticed something similar happening around you? That observation is the first step to understanding.",
          shouldQuiz: true,
        },
      ],
      intermediate: [
        {
          explanation: "This scientific principle explains phenomena we observe. Let's examine the evidence and logical steps that led scientists to this conclusion. We'll look at both the experimental data and the theoretical framework.",
          shouldQuiz: true,
        },
      ],
      advanced: [
        {
          explanation: "At this level, we need to consider the current scientific consensus, historical development of the theory, and ongoing research areas. The implications of this concept extend to multiple fields and applications.",
          shouldQuiz: true,
        },
      ],
    },
    cs: {
      beginner: [
        {
          explanation: "Programming is like giving instructions to a computer! Let's think of this concept as a recipe. What ingredients do you think we need? Understanding the basics first makes everything else easier.",
          shouldQuiz: true,
        },
      ],
      intermediate: [
        {
          explanation: "This programming concept builds on fundamental principles of computer science. Let's examine both the theoretical underpinnings and practical implementation patterns. We'll also consider performance implications.",
          shouldQuiz: true,
        },
      ],
      advanced: [
        {
          explanation: "We need to analyze this from multiple perspectives: computational complexity, memory management, and system architecture. The trade-offs involved here are crucial for understanding when and how to apply this concept effectively.",
          shouldQuiz: true,
        },
      ],
    },
  };

  return baseResponses[subject]?.[level] || baseResponses.general.beginner;
}