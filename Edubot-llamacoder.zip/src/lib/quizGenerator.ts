import type { Quiz } from "../types";

export function generateQuiz(explanation: string, subject: string): Quiz {
  const quizTemplates = {
    general: [
      {
        question: "What's the main takeaway from this explanation?",
        options: ["The concept is simple", "Understanding requires multiple steps", "It's not important", "Only experts need to know"],
        correctAnswer: "Understanding requires multiple steps",
        explanation: "Complex concepts often require breaking them down into manageable parts.",
      },
      {
        question: "How should you approach learning this topic?",
        options: ["Memorize everything", "Start with basics and build up", "Skip the details", "Only read the summary"],
        correctAnswer: "Start with basics and build up",
        explanation: "Building knowledge progressively ensures better understanding and retention.",
      },
    ],
    math: [
      {
        question: "What's the best way to understand a mathematical concept?",
        options: ["Memorize formulas", "Practice problems", "Skip proofs", "Only use calculators"],
        correctAnswer: "Practice problems",
        explanation: "Mathematics is learned through active problem-solving and application.",
      },
    ],
    science: [
      {
        question: "How do scientists validate their explanations?",
        options: ["Guessing", "Experiments and evidence", "Opinions", "Tradition"],
        correctAnswer: "Experiments and evidence",
        explanation: "Scientific knowledge is built on empirical evidence and repeatable experiments.",
      },
    ],
    cs: [
      {
        question: "What's essential for writing good code?",
        options: ["Making it complex", "Clarity and efficiency", "Using many features", "Writing quickly"],
        correctAnswer: "Clarity and efficiency",
        explanation: "Good code balances readability with performance and maintainability.",
      },
    ],
  };

  const templates = quizTemplates[subject] || quizTemplates.general;
  return templates[Math.floor(Math.random() * templates.length)];
}