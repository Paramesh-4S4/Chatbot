import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { RadioGroup, RadioGroupItem } from "../components/ui/radio-group";
import { Label } from "../components/ui/label";
import { Button } from "../components/ui/button";
import { CheckCircle, Brain } from "lucide-react";
import { useState } from "react";
import type { Quiz } from "../types";

interface QuizCardProps {
  quiz: Quiz;
  onAnswer: (answer: string) => void;
}

export function QuizCard({ quiz, onAnswer }: QuizCardProps) {
  const [selectedAnswer, setSelectedAnswer] = useState("");
  const [hasSubmitted, setHasSubmitted] = useState(false);

  const handleSubmit = () => {
    if (selectedAnswer) {
      setHasSubmitted(true);
      onAnswer(selectedAnswer);
    }
  };

  return (
    <Card className="bg-gradient-to-r from-teal-50 to-blue-50 border-teal-200">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-teal-900">
          <Brain className="w-5 h-5" />
          Quick Check
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-slate-700 font-medium">{quiz.question}</p>
        
        <RadioGroup value={selectedAnswer} onValueChange={setSelectedAnswer}>
          {quiz.options.map((option, index) => (
            <div key={index} className="flex items-center space-x-2">
              <RadioGroupItem value={option} id={`option-${index}`} />
              <Label htmlFor={`option-${index}`} className="text-slate-700 cursor-pointer">
                {option}
              </Label>
            </div>
          ))}
        </RadioGroup>
        
        <Button
          onClick={handleSubmit}
          disabled={!selectedAnswer || hasSubmitted}
          className="w-full bg-teal-600 hover:bg-teal-700"
        >
          {hasSubmitted ? (
            <>
              <CheckCircle className="w-4 h-4 mr-2" />
              Submitted
            </>
          ) : (
            "Check Answer"
          )}
        </Button>
      </CardContent>
    </Card>
  );
}