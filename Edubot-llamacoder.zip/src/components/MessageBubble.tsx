import { User, BookOpen } from "lucide-react";
import type { Message } from "../types";

interface MessageBubbleProps {
  message: Message;
}

export function MessageBubble({ message }: MessageBubbleProps) {
  const isUser = message.type === "user";
  const isQuiz = message.isQuiz;

  return (
    <div className={`flex gap-3 ${isUser ? "justify-end" : "justify-start"}`}>
      {!isUser && (
        <div className="w-8 h-8 bg-teal-100 rounded-full flex items-center justify-center flex-shrink-0">
          <BookOpen className="w-4 h-4 text-teal-700" />
        </div>
      )}
      
      <div
        className={`max-w-lg px-4 py-3 rounded-lg ${
          isUser
            ? "bg-slate-900 text-white ml-12"
            : isQuiz
            ? "bg-amber-50 border border-amber-200 text-amber-900"
            : "bg-white border-l-4 border-teal-500 text-slate-900 shadow-sm"
        }`}
      >
        <p className="text-sm leading-relaxed whitespace-pre-wrap">
          {message.content}
        </p>
        {message.level && (
          <span className="text-xs opacity-70 mt-2 block">
            Level: {message.level}
          </span>
        )}
      </div>
      
      {isUser && (
        <div className="w-8 h-8 bg-slate-700 rounded-full flex items-center justify-center flex-shrink-0">
          <User className="w-4 h-4 text-white" />
        </div>
      )}
    </div>
  );
}