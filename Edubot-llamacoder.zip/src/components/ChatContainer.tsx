import { useState, useRef, useEffect } from "react";
import { MessageBubble } from "./MessageBubble";
import { QuizCard } from "./QuizCard";
import { Button } from "../components/ui/button";
import { Textarea } from "../components/ui/textarea";
import { Send, Sparkles } from "lucide-react";
import { generateResponse, detectLevel } from "../lib/teachingEngine";
import { generateQuiz } from "../lib/quizGenerator";
import type { Message, Quiz } from "../types";

interface ChatContainerProps {
  subject: string;
}

export function ChatContainer({ subject }: ChatContainerProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      type: "bot",
      content: "Hello! I'm EduBot, your learning companion. What would you like to explore today? I'll guide you through concepts step by step.",
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [currentQuiz, setCurrentQuiz] = useState<Quiz | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, currentQuiz]);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: "user",
      content: input,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setIsTyping(true);
    setCurrentQuiz(null);

    // Simulate processing time
    await new Promise((resolve) => setTimeout(resolve, 1000));

    const level = detectLevel(input, subject);
    const response = generateResponse(input, subject, level);

    const botMessage: Message = {
      id: (Date.now() + 1).toString(),
      type: "bot",
      content: response.explanation,
      timestamp: new Date(),
      level,
    };

    setMessages((prev) => [...prev, botMessage]);

    // Generate quiz after explanation
    if (response.shouldQuiz) {
      await new Promise((resolve) => setTimeout(resolve, 500));
      const quiz = generateQuiz(response.explanation, subject);
      setCurrentQuiz(quiz);
    }

    setIsTyping(false);
  };

  const handleQuizAnswer = (answer: string) => {
    if (!currentQuiz) return;

    const isCorrect = answer === currentQuiz.correctAnswer;
    const feedbackMessage: Message = {
      id: Date.now().toString(),
      type: "bot",
      content: isCorrect
        ? `✓ Correct! ${currentQuiz.explanation}`
        : `Not quite. ${currentQuiz.explanation}`,
      timestamp: new Date(),
      isQuiz: true,
    };

    setMessages((prev) => [...prev, feedbackMessage]);
    setCurrentQuiz(null);
  };

  return (
    <div className="flex-1 flex flex-col">
      <div className="flex-1 overflow-y-auto px-6 py-4">
        <div className="max-w-3xl mx-auto space-y-4">
          {messages.map((message) => (
            <MessageBubble key={message.id} message={message} />
          ))}
          
          {isTyping && (
            <div className="flex gap-3 items-start">
              <div className="w-8 h-8 bg-teal-100 rounded-full flex items-center justify-center flex-shrink-0">
                <Sparkles className="w-4 h-4 text-teal-700 animate-pulse" />
              </div>
              <div className="bg-white border border-slate-200 rounded-lg px-4 py-3 shadow-sm">
                <div className="flex gap-1">
                  <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
                  <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                  <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
                </div>
              </div>
            </div>
          )}
          
          {currentQuiz && (
            <QuizCard quiz={currentQuiz} onAnswer={handleQuizAnswer} />
          )}
          
          <div ref={messagesEndRef} />
        </div>
      </div>

      <div className="border-t border-slate-200 bg-white px-6 py-4">
        <div className="max-w-3xl mx-auto">
          <div className="flex gap-3">
            <Textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask a question..."
              className="min-h-[44px] max-h-32 resize-none border-slate-300 focus:border-teal-500 focus:ring-teal-500"
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  handleSend();
                }
              }}
            />
            <Button
              onClick={handleSend}
              disabled={!input.trim() || isTyping}
              className="px-4 bg-teal-600 hover:bg-teal-700"
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
          <p className="text-xs text-slate-500 mt-2">
            Press Enter to send, Shift+Enter for new line
          </p>
        </div>
      </div>
    </div>
  );
}