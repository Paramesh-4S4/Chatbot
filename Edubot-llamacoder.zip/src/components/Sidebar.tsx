import { Button } from "../components/ui/button";
import { Card, CardContent } from "../components/ui/card";
import { Menu, X, Calculator, Atom, Code, Brain } from "lucide-react";

interface SidebarProps {
  selectedSubject: string;
  onSubjectChange: (subject: string) => void;
  isOpen: boolean;
  onToggle: () => void;
}

const subjects = [
  { id: "general", name: "General", icon: Brain, color: "bg-blue-100 text-blue-700" },
  { id: "math", name: "Mathematics", icon: Calculator, color: "bg-purple-100 text-purple-700" },
  { id: "science", name: "Science", icon: Atom, color: "bg-green-100 text-green-700" },
  { id: "cs", name: "Computer Science", icon: Code, color: "bg-orange-100 text-orange-700" },
];

export function Sidebar({ selectedSubject, onSubjectChange, isOpen, onToggle }: SidebarProps) {
  return (
    <>
      {isOpen && (
        <div className="w-64 bg-white border-r border-slate-200 p-4">
          <div className="mb-6">
            <h2 className="text-sm font-semibold text-slate-900 uppercase tracking-wider mb-3">
              Learning Subjects
            </h2>
            <div className="space-y-2">
              {subjects.map((subject) => {
                const Icon = subject.icon;
                return (
                  <Button
                    key={subject.id}
                    variant={selectedSubject === subject.id ? "default" : "ghost"}
                    className={`w-full justify-start gap-3 ${
                      selectedSubject === subject.id
                        ? "bg-teal-600 hover:bg-teal-700 text-white"
                        : "hover:bg-slate-100 text-slate-700"
                    }`}
                    onClick={() => onSubjectChange(subject.id)}
                  >
                    <div className={`p-1.5 rounded ${selectedSubject === subject.id ? "bg-white/20" : subject.color}`}>
                      <Icon className="w-4 h-4" />
                    </div>
                    {subject.name}
                  </Button>
                );
              })}
            </div>
          </div>
          
          <Card className="bg-slate-50 border-slate-200">
            <CardContent className="p-4">
              <h3 className="font-medium text-slate-900 mb-2">How EduBot Works</h3>
              <ul className="text-sm text-slate-600 space-y-1">
                <li>• Asks guiding questions first</li>
                <li>• Adapts to your level</li>
                <li>• Tests understanding with quizzes</li>
                <li>• Builds knowledge step by step</li>
              </ul>
            </CardContent>
          </Card>
        </div>
      )}
      
      <Button
        variant="outline"
        size="icon"
        className="fixed top-4 left-4 z-50 bg-white border-slate-300"
        onClick={onToggle}
      >
        {isOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
      </Button>
    </>
  );
}