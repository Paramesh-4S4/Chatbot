import { useState } from "react";
import { Sidebar } from "./components/Sidebar";
import { ChatContainer } from "./components/ChatContainer";
import { Book } from "lucide-react";

export default function EduBot() {
  const [selectedSubject, setSelectedSubject] = useState("general");
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  return (
    <div className="flex h-screen bg-slate-50">
      <Sidebar
        selectedSubject={selectedSubject}
        onSubjectChange={setSelectedSubject}
        isOpen={isSidebarOpen}
        onToggle={() => setIsSidebarOpen(!isSidebarOpen)}
      />
      
      <main className="flex-1 flex flex-col">
        <header className="bg-white border-b border-slate-200 px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-teal-100 rounded-lg">
              <Book className="w-5 h-5 text-teal-700" />
            </div>
            <div>
              <h1 className="text-xl font-semibold text-slate-900">EduBot</h1>
              <p className="text-sm text-slate-600">Your Intelligent Learning Companion</p>
            </div>
          </div>
        </header>
        
        <ChatContainer subject={selectedSubject} />
      </main>
    </div>
  );
}