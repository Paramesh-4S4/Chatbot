interface SubjectKeywords {
  beginner: string[];
  intermediate: string[];
  advanced: string[];
}

interface Keywords {
  general: SubjectKeywords;
  math: SubjectKeywords;
  science: SubjectKeywords;
  cs: SubjectKeywords;
}

const keywords: Keywords = {
  general: {
    beginner: ["what", "who", "when", "where"],
    intermediate: ["how", "why", "explain", "compare"],
    advanced: ["analyze", "evaluate", "synthesize", "critique"],
  },
  math: {
    beginner: ["number", "count", "add", "subtract"],
    intermediate: ["equation", "function", "graph", "solve"],
    advanced: ["derivative", "integral", "matrix", "algorithm", "complexity", "theorem", "proof"],
  },
  science: {
    beginner: ["plant", "animal", "water", "air"],
    intermediate: ["molecule", "cell", "energy", "force"],
    advanced: ["quantum", "relativity", "evolution", "thermodynamics", "photosynthesis"],
  },
  cs: {
    beginner: ["computer", "program", "code", "website"],
    intermediate: ["variable", "function", "loop", "array"],
    advanced: ["algorithm", "complexity", "recursion", "polymorphism", "asynchronous", "database"],
  },
};

export function getKeywordsBySubject(subject: string): SubjectKeywords {
  return keywords[subject] || keywords.general;
}